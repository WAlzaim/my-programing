import os
from pathlib import Path
import pandas as pd
import numpy as np


BASE_DIR = Path(__file__).resolve().parent
os.environ.setdefault("MPLCONFIGDIR", str(BASE_DIR / ".matplotlib-cache"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

COLUMN_MAP = {
    "Hour": "hour",
    "Cell_Count": "cell_count",
    "Viability_pct": "viability",
    "Average_Size_um": "cell_size",
}


# Functions

def load_csv(path):
    """Load a single culture CSV file."""
    return pd.read_csv(path)


def load_data(paths):
    """Load one or more culture CSV files and combine them into one table."""
    frames = []

    for path in paths:
        path = Path(path)
        df = load_csv(path)
        df = df.rename(columns=COLUMN_MAP)
        df["culture"] = path.stem
        df = df.sort_values("hour").reset_index(drop=True)
        frames.append(df)

    if not frames:
        raise FileNotFoundError(f"No culture CSV files found in {DATA_DIR}")

    return pd.concat(frames, ignore_index=True)


def growth_metrics(df):
    """Compute average cell count, viability, size, and final count."""
    return {
        "average_cell_count": df["cell_count"].mean(),
        "average_viability": df["viability"].mean(),
        "average_cell_size": df["cell_size"].mean(),
        "final_cell_count": df["cell_count"].iloc[-1],
    }


def growth_ratio(df):
    """Add the percent change in cell count from one time step to the next."""
    result = df.copy()
    result["growth_ratio"] = result["cell_count"].pct_change()
    return result


def rolling_growth(df, window=3, column_name="rolling_growth"):
    """Add a rolling average of the growth ratio."""
    result = df.copy()

    if "growth_ratio" not in result.columns:
        result = growth_ratio(result)

    result[column_name] = (
        result["growth_ratio"]
        .rolling(window=window, min_periods=1)
        .mean()
    )
    return result


def first_major_viability_drop(df, threshold=10):
    """Flag viability drops greater than the threshold and mark the first one."""
    result = df.copy()
    drops = result["viability"].diff() < -threshold

    result["viability_drop_B"] = drops
    result["first_major_viability_drop_B"] = False

    if drops.any():
        first_drop_index = drops[drops].index[0]
        result.loc[first_drop_index, "first_major_viability_drop_B"] = True

    return result


def size_jump_flags(df, threshold=0.15):
    """Flag unusual jumps in average cell size."""
    result = df.copy()
    result["size_jump_C"] = result["cell_size"].pct_change().abs() > threshold
    return result


def predict_next_count(df, recent_steps=3):
    """Predict the next cell count from recent cell-count changes."""
    changes = df["cell_count"].diff().dropna().tail(recent_steps)

    if changes.empty:
        return int(df["cell_count"].iloc[-1])

    prediction = df["cell_count"].iloc[-1] + changes.mean()
    return int(round(max(prediction, 0)))


def recommend_harvest_window(df, viability_cutoff=90, count_fraction=0.85):
    """Recommend the earliest hour with high count and healthy viability."""
    high_count = df["cell_count"] >= df["cell_count"].max() * count_fraction
    healthy = df["viability"] >= viability_cutoff
    candidates = df[high_count & healthy]

    if not candidates.empty:
        hour = candidates.iloc[0]["hour"]
        return f"Hour {hour}: high count with viability >= {viability_cutoff}%"

    best_row = df.loc[df["cell_count"].idxmax()]
    return f"Hour {best_row['hour']}: highest count, but check viability"


# Main

def main():
    # Phase 1: Load one culture and compute core metrics

    files = sorted(DATA_DIR.glob("culture_day_A.csv"))

    if not files:
        raise FileNotFoundError(f"No culture_day_A.csv files found in {DATA_DIR}")

    first_file = files[0]
    df = load_data([first_file])

    phase1_summary = growth_metrics(df)

    pd.DataFrame([phase1_summary]).to_csv(
        OUTPUT_DIR / "phase1_summary.csv", index=False
    )

    plt.figure()
    plt.plot(df["hour"], df["cell_count"])
    plt.xlabel("Hour")
    plt.ylabel("Cell Count")
    plt.title("Cell Count Over Time")
    plt.savefig(OUTPUT_DIR / "cell_count_plot.png")
    plt.close()

    plt.figure()
    plt.plot(df["hour"], df["viability"], color='red')
    plt.xlabel("Hour")
    plt.ylabel("Viability")
    plt.title("Viability Over Time")
    plt.savefig(OUTPUT_DIR / "viability_plot.png")
    plt.close()

    (OUTPUT_DIR / "phase1_reflection.md").write_text(
        "Phase 1 Reflection\n"
        "------------------\n"
        "The culture shows steady growth over time.\n"
        "Viability remains relatively stable.\n"
        "The dataset is suitable for comparison in later phases.\n",
        encoding="utf-8",
    )

    # Phase 2: Compare multiple cultures and variants

    culture_files = sorted(DATA_DIR.glob("culture_day_*.csv"))
    combined = load_data(culture_files)

    processed_frames = []

    for _, culture_df in combined.groupby("culture", sort=False):
        culture_df = growth_ratio(culture_df)

        # Variant A: rolling growth ratio
        culture_df = rolling_growth(
            culture_df, window=3, column_name="rolling_growth_A1"
        )
        culture_df = rolling_growth(
            culture_df, window=5, column_name="rolling_growth_A2"
        )

        # Variant B: first major viability drop
        culture_df = first_major_viability_drop(culture_df)

        # Variant C: unusual size jump flags
        culture_df = size_jump_flags(culture_df)

        processed_frames.append(culture_df)

    combined = pd.concat(processed_frames, ignore_index=True)

    phase2_summary = (
        combined
        .groupby("culture")
        .agg(
            final_cell_count=("cell_count", "last"),
            average_viability=("viability", "mean"),
            mean_cell_size=("cell_size", "mean"),
            rolling_A1_mean=("rolling_growth_A1", "mean"),
            rolling_A2_mean=("rolling_growth_A2", "mean"),
            viability_drops=("viability_drop_B", "sum"),
            first_major_drops=("first_major_viability_drop_B", "sum"),
            size_jumps=("size_jump_C", "sum"),
        )
        .sort_values("final_cell_count", ascending=False)
        .reset_index()
    )

    final_variant_rows = []
    for culture, culture_df in combined.groupby("culture", sort=False):
        final_variant_rows.append({
            "culture": culture,
            "predicted_next_count": predict_next_count(culture_df),
            "harvest_window": recommend_harvest_window(culture_df),
            "suspicious_events": int(
                culture_df["viability_drop_B"].sum()
                + culture_df["size_jump_C"].sum()
            ),
        })

    final_variants = pd.DataFrame(final_variant_rows)
    phase2_summary = phase2_summary.merge(final_variants, on="culture", how="left")

    phase2_summary.to_csv(OUTPUT_DIR / "phase2_summary.csv", index=False)

    plt.figure()
    plt.bar(phase2_summary["culture"], phase2_summary["final_cell_count"])
    plt.xlabel("Culture")
    plt.ylabel("Final Cell Count")
    plt.title("Final Cell Count Comparison")
    plt.savefig(OUTPUT_DIR / "cell_count_comparison.png")
    plt.close()

    notes = []
    for _, row in phase2_summary.iterrows():
        notes.append(
            f"{row['culture']}: "
            f"{int(row['viability_drops'])} viability drops, "
            f"{int(row['size_jumps'])} size jumps, "
            f"next count predicted at {int(row['predicted_next_count'])}. "
            f"Harvest recommendation: {row['harvest_window']}."
        )

    (OUTPUT_DIR / "phase2_notes.md").write_text(
        "Phase 2 Notes\n"
        "-------------\n" +
        "\n".join(notes),
        encoding="utf-8",
    )

    # Phase 3: Batch processing, dashboard, and report

    combined.to_csv(OUTPUT_DIR / "combined_culture_data.csv", index=False)

    first_culture = combined["culture"].iloc[0]
    one = combined[combined["culture"] == first_culture]

    plt.figure(figsize=(10, 8))

    plt.subplot(2, 2, 1)
    plt.plot(one["hour"], one["cell_count"], color='pink')
    plt.title("Cell Count")

    plt.subplot(2, 2, 2)
    plt.plot(one["hour"], one["viability"])
    plt.title("Viability")

    plt.subplot(2, 2, 3)
    plt.plot(one["hour"], one["cell_size"])
    plt.title("Cell Size")

    plt.subplot(2, 2, 4)
    plt.bar(phase2_summary["culture"], phase2_summary["final_cell_count"])
    plt.title("Final Counts")

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "culture_dashboard.png")
    plt.close()

    best = phase2_summary.iloc[0]["culture"]
    worst = phase2_summary.iloc[-1]["culture"]

    report_lines = [
        f"Strongest growth culture: {best}",
        f"Weakest growth culture: {worst}",
        "",
        "Final Variant Summary",
        "---------------------",
    ]

    for _, row in phase2_summary.iterrows():
        report_lines.extend([
            f"{row['culture']}:",
            f"Predicted next count: {int(row['predicted_next_count'])}",
            f"Harvest window: {row['harvest_window']}",
            f"Suspicious drops/jumps: {int(row['suspicious_events'])}",
            "",
        ])

    (OUTPUT_DIR / "phase3_report.txt").write_text(
        "\n".join(report_lines),
        encoding="utf-8",
    )

    print(f"All phases complete. Outputs saved to {OUTPUT_DIR}.")


if __name__ == "__main__":
    main()
