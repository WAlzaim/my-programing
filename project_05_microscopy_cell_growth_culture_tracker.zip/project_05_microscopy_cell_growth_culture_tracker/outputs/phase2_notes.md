Phase 2 Notes
-------------
culture_day_B: 0 viability drops, 0 size jumps, next count predicted at 20680. Harvest recommendation: Hour 72: highest count, but check viability.
culture_day_A: 0 viability drops, 0 size jumps, next count predicted at 10158. Harvest recommendation: Hour 72: highest count, but check viability.
culture_day_C: 0 viability drops, 0 size jumps, next count predicted at 9388. Harvest recommendation: Hour 72: highest count, but check viability.